
%清空頁面
clc;
close all;
clear;

% 設定參數
A1=523; A2=1.2*A1;
f=1000; T=1/f;
D=29; M=2;
tm1=(37.2/M)*T;
tm2=-(41.3/D)*T;

tt=-T:1/40000:T; % 時間t軸
% 訊號函數
x1=A1*cos(2*pi*(1000)*(tt-tm1));
x2=A2*cos(2*pi*(1000)*(tt-tm2));
x3=x1-x2;

% 畫出訊號圖
subplot(3,1,1);plot(tt,x1,'b');title('X1=A1*cos(2*pi*(1000)*(tt-tm1))');
subplot(3,1,2);plot(tt,x2,'r');title('X2=A2*cos(2*pi*(1000)*(tt-tm2))');
subplot(3,1,3);plot(tt,x3,'g');title('X3=X1-X2');











