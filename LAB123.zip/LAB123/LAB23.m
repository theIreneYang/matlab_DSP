
%清空頁面
clc;
close all;
clear;

%不同頻率fk和振幅Xk的組合(fk,Xk,fs,dur,tstart)
%呼叫副函式LAB23_syn_sin做波值加總
[xx1,tt1]=LAB23_syn_sin([0,150,250],[10,16*exp(-j*pi/4),6*j],10000,0.1,0);
[xx2,tt2]=LAB23_syn_sin([0,150,250,350],[10,16*exp(-j*pi/4),6*j,0],10000,0.1,0);

%畫出疊加波型
figure()
plot(tt1,xx1);title('figure 1');
figure()
plot(tt2,xx2);title('figure 2');
