
function[xx,tt]=LAB23_syn_sin(fk,Xk,fs,dur,tstart)

xx=0; %x(t)初始值=0
tt=tstart:1/fs:dur; %根據主程式:t軸為0~0.1秒，頻率為10k(間隔為1s/10k)

for k=1:length(fk) %k=1:3 or 1:4 (不同頻率和振幅的組合數量)
x=real(Xk(k)*exp(j*2*pi*fk(k)*tt)); %波的方程式，取實數
xx=xx+x; %與前一次波值做加總直到k=3or4
end

end




